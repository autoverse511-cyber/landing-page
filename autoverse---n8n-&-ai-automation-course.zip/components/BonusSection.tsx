import React from 'react';
import { motion } from 'framer-motion';
import { Gift, Check } from 'lucide-react';

const BonusSection: React.FC = () => {
  return (
    <section className="py-24 relative overflow-hidden bg-black">
      {/* Decorative */}
      <div className="absolute inset-0 bg-grid opacity-30"></div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="bg-[#0a0a0a] border border-accent/20 rounded-3xl p-8 md:p-12 flex flex-col md:flex-row items-center gap-12 relative overflow-hidden">
          
          {/* Accent glow */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-accent/5 rounded-full blur-[100px] pointer-events-none -translate-y-1/2 translate-x-1/2"></div>

          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="flex-1 text-right relative z-10"
          >
            <div className="inline-flex items-center gap-2 bg-accent/10 text-accent px-4 py-1 rounded-full mb-6 border border-accent/20">
              <Gift size={18} />
              <span className="font-bold">هدية خاصة لكل مشترك!</span>
            </div>
            <h2 className="text-3xl md:text-5xl font-bold mb-6 text-white">كتاب الأتمتة الشامل</h2>
            <p className="text-lg text-gray-300 mb-8">
              لا تكتفِ بالفيديو فقط! احصل على مرجعك الدائم المكتوب. يحتوي الكتاب على شروحات إضافية، أكواد جاهزة، ونصائح متقدمة لا غنى عنها لأي خبير أتمتة.
            </p>
            <ul className="space-y-4 mb-8">
              {[
                "دليل مرجعي للـ Nodes الأكثر استخداماً",
                "أكواد JavaScript جاهزة للنسخ واللصق",
                "أفضل الممارسات للأمان والسرعة",
              ].map((item, i) => (
                <li key={i} className="flex items-center gap-3 text-gray-300 font-medium">
                  <div className="bg-accent/20 p-1 rounded-full text-accent">
                     <Check size={12} />
                  </div>
                  {item}
                </li>
              ))}
            </ul>
            <div className="text-2xl font-bold text-accent">مجاناً تماماً مع الكورس 🎁</div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0, rotate: -5, scale: 0.9 }}
            whileInView={{ opacity: 1, rotate: 0, scale: 1 }}
            transition={{ type: "spring", bounce: 0.5 }}
            viewport={{ once: true }}
            className="w-full md:w-1/3 flex justify-center relative"
          >
            {/* 3D Book Mockup */}
            <div className="relative group w-[260px] h-[360px] perspective-1000">
                <div className="w-full h-full bg-[#111] rounded-r-lg border-l-[12px] border-l-[#222] shadow-[0_20px_50px_rgba(0,0,0,0.5)] flex flex-col items-center justify-center p-6 text-center relative z-10 border border-white/10 group-hover:-translate-y-2 transition-transform duration-500">
                    {/* Book Cover Design */}
                    <div className="absolute inset-0 border border-accent/30 rounded-r-lg m-1"></div>
                    <div className="text-accent font-bold text-4xl mb-2 tracking-tighter">n8n</div>
                    <div className="w-16 h-1 bg-white/20 mb-8"></div>
                    <div className="text-white text-lg font-bold">دليلك الشامل<br/>للأتمتة</div>
                    
                    <div className="absolute bottom-8 text-[10px] text-gray-500 tracking-[0.3em]">AUTOVERSE</div>
                </div>
                {/* Book Pages */}
                <div className="absolute top-[3px] right-[4px] w-[250px] h-[354px] bg-white rounded-r-md z-0 shadow-lg"></div>
                <div className="absolute top-[6px] right-[8px] w-[250px] h-[354px] bg-gray-300 rounded-r-md -z-10 shadow-lg"></div>
                
                {/* Neon Glow behind book */}
                <div className="absolute inset-0 bg-accent blur-[60px] opacity-20 -z-20 group-hover:opacity-40 transition-opacity"></div>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
};

export default BonusSection;
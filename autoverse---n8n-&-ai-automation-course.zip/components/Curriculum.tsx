import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, PlayCircle, Clock } from 'lucide-react';
import { CURRICULUM_DATA } from '../constants';
import { Module } from '../types';

const Curriculum: React.FC = () => {
  const [openModuleIndex, setOpenModuleIndex] = useState<number | null>(0);

  const toggleModule = (index: number) => {
    setOpenModuleIndex(openModuleIndex === index ? null : index);
  };

  return (
    <section id="curriculum" className="py-24 bg-surface border-y border-white/5">
      <div className="container mx-auto px-6 max-w-4xl">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-white">المحتوى التدريبي الشامل</h2>
          <p className="text-gray-400">خطة دراسية منظمة تأخذك من الصفر إلى الاحتراف</p>
        </div>

        <div className="space-y-4">
          {CURRICULUM_DATA.map((module: Module, index: number) => (
            <div 
              key={index} 
              className={`border rounded-xl transition-all duration-300 ${openModuleIndex === index ? 'bg-white/5 border-primary/30 shadow-[0_0_15px_rgba(0,255,136,0.05)]' : 'bg-[#0f0f0f] border-white/5 hover:border-white/10'}`}
            >
              <button
                onClick={() => toggleModule(index)}
                className="w-full flex items-center justify-between p-6 text-right focus:outline-none"
              >
                <div className="flex items-center gap-4">
                    <motion.div 
                        animate={{ rotate: openModuleIndex === index ? 180 : 0 }}
                        className={`text-gray-400 ${openModuleIndex === index ? 'text-primary' : ''}`}
                    >
                        <ChevronDown />
                    </motion.div>
                    <div className="flex flex-col items-start gap-1">
                        <span className={`text-xl font-bold flex items-center gap-3 ${openModuleIndex === index ? 'text-primary' : 'text-white'}`}>
                            <span className={openModuleIndex === index ? 'text-primary' : 'text-gray-500'}>{module.icon}</span>
                            {module.title}
                        </span>
                        <span className="text-sm text-gray-500 mr-9">{module.lessons.length} دروس</span>
                    </div>
                </div>
              </button>

              <AnimatePresence>
                {openModuleIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <div className="p-6 pt-0 space-y-4 mr-4 border-r border-white/10">
                      {module.lessons.map((lesson, lessonIndex) => (
                        <div key={lessonIndex} className="bg-black/30 p-4 rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-bold text-gray-200 flex items-center gap-2 text-sm md:text-base">
                                <PlayCircle size={16} className="text-primary/60" />
                                {lesson.title}
                            </h4>
                          </div>
                          
                          {/* Sub items */}
                          <ul className="space-y-2 mr-6 mt-3">
                            {lesson.items.map((sub, subIndex) => (
                                <li key={subIndex} className="text-xs md:text-sm text-gray-500 flex items-start gap-2">
                                    <span className="w-1 h-1 bg-gray-600 rounded-full mt-2 shrink-0"></span>
                                    {sub.title}
                                </li>
                            ))}
                          </ul>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Curriculum;
import React from 'react';

const EmergencyBar: React.FC = () => {
  return (
    <div className="bg-primary/10 text-white text-sm py-2 px-4 text-center border-b border-primary/20 backdrop-blur-sm sticky top-0 z-[60]">
      <div className="container mx-auto flex flex-col md:flex-row items-center justify-center gap-2 md:gap-4">
        <span className="flex items-center gap-2 font-bold text-primary">
          🚀 ابدأ رحلة احتراف الأتمتة والذكاء الاصطناعي اليوم
        </span>
        <button 
          onClick={() => window.open('https://wa.me/201285060097', '_blank')}
          className="bg-primary text-black px-3 py-1 rounded text-xs font-bold hover:bg-white transition-colors"
        >
          اشترك الآن
        </button>
      </div>
    </div>
  );
};

export default EmergencyBar;
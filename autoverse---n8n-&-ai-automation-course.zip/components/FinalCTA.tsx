import React from 'react';
import { ArrowLeft } from 'lucide-react';

const FinalCTA: React.FC = () => {
  const openWhatsApp = () => {
    window.open('https://wa.me/201285060097', '_blank');
  };

  return (
    <section id="final-cta" className="py-24 text-center relative overflow-hidden bg-primary">
      <div className="absolute inset-0 bg-black/90 skew-y-3 scale-110"></div>
      
      <div className="container mx-auto px-6 relative z-10">
        <div className="w-16 h-1 bg-primary mx-auto mb-8 animate-pulse"></div>
        
        <h2 className="text-3xl md:text-5xl font-bold mb-6 text-white">لا تترك هذا القرار لليوم الثاني 🚨</h2>
        <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto">
          الفرصة متاحة الآن لتغيير مسارك المهني. السعر سيرتفع بمجرد انتهاء العداد.
        </p>
        
        <div className="flex flex-col items-center gap-4">
            <div className="text-3xl font-black text-white flex gap-4 items-center">
                <span className="text-primary">1500 جنيه</span>
            </div>
            
            <button 
                onClick={openWhatsApp}
                className="px-12 py-5 rounded-full font-bold bg-primary text-black hover:bg-white hover:text-black shadow-[0_0_30px_rgba(0,255,136,0.5)] hover:shadow-[0_0_50px_rgba(255,255,255,0.5)] transition-all text-xl flex items-center gap-3 group">
                اشترك الآن فوراً
                <ArrowLeft className="group-hover:-translate-x-1 transition-transform" />
            </button>
            
            <p className="mt-4 text-gray-400 font-bold text-sm bg-black/50 px-4 py-1 rounded">
                استثمارك في نفسك هو الأفضل دائماً
            </p>
        </div>
      </div>
    </section>
  );
};

export default FinalCTA;
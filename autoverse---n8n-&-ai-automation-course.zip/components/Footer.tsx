import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black py-8 border-t border-white/5 text-center text-gray-600 text-sm relative z-20">
      <div className="container mx-auto px-6">
        <p>جميع الحقوق محفوظة © {new Date().getFullYear()} | <span className="text-primary font-bold">AutoVerse</span> — كورس n8n والأتمتة الذكية</p>
      </div>
    </footer>
  );
};

export default Footer;
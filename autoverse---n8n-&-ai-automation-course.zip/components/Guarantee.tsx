import React from 'react';
import { ShieldCheck } from 'lucide-react';

const Guarantee: React.FC = () => {
  return (
    <section className="py-12 bg-surface border-y border-white/5">
      <div className="container mx-auto px-6 flex justify-center">
        <div className="max-w-2xl bg-[#0f0f0f] border border-white/10 p-8 rounded-2xl flex flex-col md:flex-row items-center gap-6 text-center md:text-right">
            <ShieldCheck size={64} className="text-accent shrink-0" />
            <div>
                <h3 className="text-xl font-bold text-white mb-2">ضمان استرداد كامل خلال 7 أيام</h3>
                <p className="text-gray-400 text-sm">
                    نحن واثقون من جودة المحتوى. إذا لم يعجبك الكورس لأي سبب خلال 7 أيام، سنعيد لك مبلغك كاملاً بدون أي أسئلة. المخاطرة علينا بالكامل. 🛡️
                </p>
            </div>
        </div>
      </div>
    </section>
  );
};

export default Guarantee;
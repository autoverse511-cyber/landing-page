import React from 'react';
import { PlayCircle, ShieldCheck, CheckCircle2, Zap } from 'lucide-react';
import { motion } from 'framer-motion';

const Hero: React.FC = () => {
  const openWhatsApp = () => {
    window.open('https://wa.me/201285060097', '_blank');
  };

  const scrollToCurriculum = () => {
    document.getElementById('curriculum')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative min-h-[90vh] flex items-center pt-10 pb-20 overflow-hidden">
      {/* Background Gradients */}
      <div className="absolute top-[-10%] right-[-10%] w-[600px] h-[600px] bg-primary/10 rounded-full blur-[120px] pointer-events-none"></div>
      <div className="absolute bottom-[-10%] left-[-10%] w-[500px] h-[500px] bg-secondary/10 rounded-full blur-[100px] pointer-events-none"></div>

      <div className="container mx-auto px-6 relative z-10 grid lg:grid-cols-2 gap-12 items-center">
        
        {/* Text Content */}
        <motion.div 
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
          className="text-right"
        >
          {/* Price Badge */}
          <div className="inline-block mb-6 relative group">
            <div className="absolute inset-0 bg-accent blur-md opacity-40 group-hover:opacity-60 transition-opacity rounded-full"></div>
            <div className="relative bg-black/80 border border-accent/50 text-accent px-4 py-1.5 rounded-full text-sm font-bold flex items-center gap-2">
               <Zap size={16} className="fill-accent" />
               <span className="text-white text-shadow-neon">1500 جنيه</span>
            </div>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold leading-tight mb-6">
            احترف الأتمتة <br/>
            وبناء <span className="text-primary text-shadow-neon">AI Agents</span><br/>
            بدون كود!
          </h1>
          
          <p className="text-lg md:text-xl text-gray-400 mb-8 leading-relaxed max-w-2xl ms-auto border-r-4 border-primary/50 pr-4">
            كورس عملي 100% لتعلم n8n وإنشاء حلول ذكية للشركات. ابدأ رحلتك في عالم الأتمتة وضاعف إنتاجيتك ودخلك اليوم.
          </p>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-10">
             {["عملي 100%", "مشاريع حقيقية", "دعم فني"].map((badge, idx) => (
                <div key={idx} className="flex items-center gap-1.5 text-xs md:text-sm text-gray-300 bg-white/5 p-2 rounded border border-white/5">
                   <CheckCircle2 size={14} className="text-primary" /> {badge}
                </div>
             ))}
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <button 
                onClick={openWhatsApp}
                className="relative px-8 py-4 rounded-lg font-bold bg-primary text-black hover:bg-[#00e676] shadow-[0_0_20px_rgba(0,255,136,0.4)] hover:shadow-[0_0_30px_rgba(0,255,136,0.6)] transition-all transform hover:-translate-y-1 flex justify-center items-center gap-2 group text-lg">
              <span>اشترك الآن وابدأ التعلم</span>
              <span className="bg-black/20 rounded px-1.5 text-sm group-hover:bg-black/30 transition-colors">فوراً 🚀</span>
            </button>
            
            <button 
                onClick={scrollToCurriculum}
                className="px-8 py-4 rounded-lg font-bold bg-transparent border border-white/20 hover:border-primary/50 hover:bg-white/5 transition-all text-white flex justify-center items-center gap-2 group">
              <span>شاهد المحتوى الكامل</span>
              <PlayCircle size={20} className="group-hover:text-primary transition-colors" />
            </button>
          </div>
          
          <div className="mt-8 flex items-center gap-4 text-xs text-gray-500">
            <div className="flex items-center gap-1">
                <ShieldCheck size={14} className="text-primary"/> دفع آمن SSL
            </div>
            <div className="h-3 w-px bg-white/10"></div>
            <div className="flex items-center gap-1">
                <ShieldCheck size={14} className="text-primary"/> ضمان استرداد 7 أيام
            </div>
          </div>
        </motion.div>

        {/* Visual */}
        <motion.div 
           initial={{ opacity: 0, x: -50 }}
           animate={{ opacity: 1, x: 0 }}
           transition={{ duration: 0.8, delay: 0.2 }}
           className="relative hidden lg:block"
        >
          {/* Abstract Node Graph Visualization */}
          <div className="relative w-full aspect-square max-w-lg mx-auto">
             <div className="absolute inset-0 bg-primary/5 rounded-full blur-3xl animate-pulse"></div>
             
             {/* Central Node */}
             <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-32 h-32 bg-surface border border-primary/50 rounded-2xl flex items-center justify-center z-20 shadow-[0_0_30px_rgba(0,255,136,0.2)]">
                <div className="text-center">
                    <div className="text-primary text-4xl font-bold mb-1">n8n</div>
                    <div className="text-xs text-gray-400">Mastery</div>
                </div>
             </div>

             {/* Satellites */}
             {[0, 72, 144, 216, 288].map((deg, i) => (
                <div key={i} className="absolute top-1/2 left-1/2 w-12 h-12 bg-surface border border-white/10 rounded-xl flex items-center justify-center z-10 shadow-lg"
                     style={{ 
                        transform: `translate(-50%, -50%) rotate(${deg}deg) translate(160px) rotate(-${deg}deg)`,
                     }}>
                   <div className="w-2 h-2 bg-primary rounded-full animate-ping absolute opacity-50"></div>
                   <div className={`w-6 h-6 rounded-full bg-gradient-to-br ${i % 2 === 0 ? 'from-blue-500 to-cyan-500' : 'from-purple-500 to-pink-500'}`}></div>
                   {/* Connecting Line */}
                   <div className="absolute top-1/2 left-1/2 w-[160px] h-[2px] bg-gradient-to-l from-primary/50 to-transparent -z-10 origin-left"
                        style={{ transform: `translateY(-50%) rotate(${deg + 180}deg)` }}></div>
                </div>
             ))}

             {/* Floating Code Snippets */}
             <div className="absolute top-10 right-0 bg-black/80 border border-white/10 p-3 rounded text-[10px] font-mono text-green-400 backdrop-blur shadow-xl animate-[bounce_3s_infinite]">
                {`{ "success": true, "agent": "active" }`}
             </div>
             <div className="absolute bottom-20 left-10 bg-black/80 border border-white/10 p-3 rounded text-[10px] font-mono text-blue-400 backdrop-blur shadow-xl animate-[bounce_4s_infinite]">
                {`await openai.complete(prompt);`}
             </div>
          </div>
        </motion.div>

      </div>
    </section>
  );
};

export default Hero;
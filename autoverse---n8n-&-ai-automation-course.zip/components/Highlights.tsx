import React from 'react';
import { motion } from 'framer-motion';
import { HIGHLIGHTS } from '../constants';

const Highlights: React.FC = () => {
  return (
    <section className="py-20 relative">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          {HIGHLIGHTS.map((item, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ y: -5, borderColor: 'rgba(0, 255, 136, 0.4)' }}
              className="bg-surface border border-white/10 rounded-lg p-6 text-center group transition-all hover:bg-surface/80 hover:shadow-[0_0_15px_rgba(0,255,136,0.1)]"
            >
              <div className={`w-12 h-12 mx-auto rounded-full bg-white/5 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform ${item.color}`}>
                {item.icon}
              </div>
              <h3 className="font-bold text-base text-gray-200">{item.text}</h3>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Highlights;
import React from 'react';
import { XCircle, CheckCircle } from 'lucide-react';

const PainPoints: React.FC = () => {
  return (
    <section className="py-20 relative bg-surface border-y border-white/5">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">هل أنت في هذا الوضع؟ 🤔</h2>
          <div className="w-16 h-1 bg-primary mx-auto"></div>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center max-w-5xl mx-auto">
            {/* The Problem */}
            <div className="space-y-6">
                {[
                    "تضيع ساعات يومياً في مهام يدوية مملة ومتكررة؟",
                    "تسمع عن الـ AI وتريد استخدامه لكن لا تعرف كيف تبدأ؟",
                    "تريد دخلاً حراً إضافياً لكن تشعر أن المنافسة عالية؟"
                ].map((text, i) => (
                    <div key={i} className="bg-red-950/20 border border-red-900/30 p-6 rounded-xl flex items-start gap-4">
                        <XCircle className="text-red-500 shrink-0 mt-1" />
                        <p className="text-gray-300 font-medium">{text}</p>
                    </div>
                ))}
            </div>

            {/* Transition Arrow (Mobile hidden) */}
            <div className="hidden md:flex justify-center text-primary text-4xl animate-pulse">
                ⬅️
            </div>

            {/* The Solution */}
            <div className="space-y-6">
                 {[
                    "حوّل المهام اليدوية إلى أنظمة تعمل تلقائياً 24/7.",
                    "ابنِ AI Agents ذكية تقوم بخدمة العملاء وتحليل البيانات.",
                    "امتلك مهارة نادرة ومطلوبة جداً تضعك في مقدمة السوق."
                ].map((text, i) => (
                    <div key={i} className="bg-green-950/20 border border-primary/20 p-6 rounded-xl flex items-start gap-4 shadow-[0_0_15px_rgba(0,255,136,0.05)]">
                        <CheckCircle className="text-primary shrink-0 mt-1" />
                        <p className="text-white font-medium">{text}</p>
                    </div>
                ))}
            </div>
        </div>
        
        <div className="mt-12 text-center">
            <h3 className="text-2xl font-bold text-white">✅ n8n هو الحل — وهذا الكورس يعلمك كل شيء من الصفر</h3>
        </div>
      </div>
    </section>
  );
};

export default PainPoints;
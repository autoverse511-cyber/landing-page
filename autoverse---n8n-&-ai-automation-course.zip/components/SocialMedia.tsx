import React from 'react';
import { SOCIAL_LINKS } from '../constants';

const SocialMedia: React.FC = () => {
  return (
    <section className="py-12 bg-black border-t border-primary/20 relative z-10">
      <div className="container mx-auto px-6">
        <div className="text-center mb-8">
          <span className="text-primary/70 text-sm font-bold uppercase tracking-widest mb-2 block">Connect With Us</span>
          <h2 className="text-2xl font-bold text-white">انضم لمجتمع AutoVerse</h2>
        </div>

        <div className="flex flex-wrap justify-center gap-4">
          {SOCIAL_LINKS.map((link, index) => (
            <a
              key={index}
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              className={`flex items-center gap-3 px-6 py-4 bg-surface border border-white/10 rounded-xl transition-all duration-300 w-full md:w-auto justify-center min-w-[200px] group ${link.color}`}
            >
              <span className="group-hover:scale-110 transition-transform">{link.icon}</span>
              <span className="font-bold">{link.platform}</span>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SocialMedia;
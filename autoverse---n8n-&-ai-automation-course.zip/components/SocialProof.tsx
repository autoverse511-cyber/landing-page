import React from 'react';
import { Star, Quote } from 'lucide-react';
import { REVIEWS } from '../constants';

const SocialProof: React.FC = () => {
  return (
    <section className="py-20 bg-surface border-y border-white/5 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-primary/20 to-transparent"></div>
      
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold mb-4">ماذا يقول طلابنا؟ ⭐</h2>
          <p className="text-gray-400">انضم لأكثر من <span className="text-primary font-bold">+1,240</span> طالب غيروا مسارهم المهني</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {REVIEWS.map((review, i) => (
            <div key={i} className="bg-[#0f0f0f] border border-white/5 p-8 rounded-2xl relative group hover:border-primary/30 transition-colors">
              <Quote className="absolute top-6 left-6 text-white/5 w-10 h-10 group-hover:text-primary/10 transition-colors" />
              
              <div className="flex gap-1 mb-4 text-accent">
                {[...Array(review.rating)].map((_, j) => <Star key={j} size={16} fill="currentColor" />)}
              </div>
              
              <p className="text-gray-300 mb-6 leading-relaxed text-sm">"{review.content}"</p>
              
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gray-700 overflow-hidden">
                    <img src={review.avatar} alt={review.name} className="w-full h-full object-cover" />
                </div>
                <div>
                    <h4 className="font-bold text-white text-sm">{review.name}</h4>
                    <span className="text-xs text-primary">{review.role}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default SocialProof;
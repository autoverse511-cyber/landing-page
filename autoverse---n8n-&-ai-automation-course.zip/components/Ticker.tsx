import React from 'react';

const Ticker: React.FC = () => {
  return (
    <div className="bg-black border-b border-primary/20 overflow-hidden py-2 relative z-50">
      <div className="whitespace-nowrap flex animate-ticker w-max">
        {[...Array(6)].map((_, i) => (
            <span key={i} className="mx-8 text-primary/80 font-bold text-sm flex items-center gap-2">
                🚀 كورس الأتمتة الشامل (بناء AI Agents) - احترف n8n الآن <span className="text-white mx-2">•</span>
            </span>
        ))}
      </div>
    </div>
  );
};

export default Ticker;
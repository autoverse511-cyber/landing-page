import React from 'react';
import { Check } from 'lucide-react';

const ValueStack: React.FC = () => {
  return (
    <section id="pricing" className="py-20 bg-black relative">
      <div className="absolute inset-0 bg-grid opacity-20"></div>

      <div className="container mx-auto px-6 max-w-3xl relative z-10">
        <div className="text-center mb-10">
          <h2 className="text-3xl font-bold text-white mb-2">ماذا ستحصل عليه مقابل استثمارك؟</h2>
          <p className="text-gray-400">قيمة لا تقارن بالسعر</p>
        </div>

        <div className="bg-surface border border-primary/30 rounded-2xl overflow-hidden shadow-[0_0_50px_rgba(0,255,136,0.1)]">
          <table className="w-full text-right">
            <thead>
              <tr className="bg-white/5 border-b border-white/10">
                <th className="p-4 text-gray-300 font-medium text-right" colSpan={2}>ما ستحصل عليه</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {[
                { name: "٨+ ساعات محتوى عملي ومكثف" },
                { name: "١٥٠٠+ قالب Workflows جاهز" },
                { name: "بناء Agents (Telegram, Messenger, WhatsApp, Website)" },
                { name: "دعم فني وتحديثات مستمرة" },
                { name: "كتاب الأتمتة الشامل (نسخة كاملة)" },
              ].map((item, index) => (
                <tr key={index} className="hover:bg-white/5 transition-colors">
                  <td className="p-4 flex items-center gap-3 text-gray-200" colSpan={2}>
                    <div className="bg-primary/20 p-1 rounded-full text-primary"><Check size={12} /></div>
                    {item.name}
                  </td>
                </tr>
              ))}
              
              <tr className="bg-primary/10">
                <td className="p-6 font-black text-xl text-primary border-t border-primary/30">السعر الكلي</td>
                <td className="p-6 font-black text-3xl text-primary text-left border-t border-primary/30 text-shadow-neon">1500 ج.م</td>
              </tr>
            </tbody>
          </table>
          
          <div className="p-6 bg-black/50 text-center">
             <button 
                onClick={() => window.open('https://wa.me/201285060097', '_blank')}
                className="w-full py-4 bg-primary text-black font-bold rounded-xl text-lg hover:bg-[#00e676] shadow-lg transition-all"
             >
                احجز مقعدك الآن
             </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ValueStack;